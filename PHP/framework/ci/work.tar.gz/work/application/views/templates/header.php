<!DOCTYPE html>

<html>
<head>
  <title><?php echo $title;?></title>
  <link href="/static/bootstrap/css/bootstrap.css" rel="stylesheet" media="screen">
  <link href="/static/bootstrap/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">
 </head>
 <body>