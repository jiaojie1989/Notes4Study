<center>
<div class="text-primary" style="text-align: center; margin-top: 100px; max-width: 1000px; margin-bottom: 20px ! important;"><h2>选择条目</h2></div>
<div class="row" style="text-align: center; margin-top: 20px; max-width: 600px; margin-bottom: 20px ! important;">
	<ul class="nav nav-pills nav-stacked alert alert-info" role="tablist">
	  
	  <li role="presentation" class=""><a href="click_data">各模块点击统计数据显示</a></li>
	  <li role="presentation"><a href="click_income">网盟市场分析数据显示</a></li>
	  <li role="presentation"><a href="click_income_alter_view">直客点击和收入完整数据</a></li>
	  <li role="presentation"><a href="#">337游戏点击统计</a></li>
	  <li role="presentation"><a href="all">直客收入整体分析数据</a></li>
	  <li role="presentation" class="active"><a href="login">退出</a></li>
	  
	</ul>
</div>
</center>
