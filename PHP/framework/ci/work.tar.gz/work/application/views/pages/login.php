<center>
<div class="text-primary" style="text-align: center; margin-top: 100px; max-width: 1000px; margin-bottom: 20px ! important;"><h2>登录</h2></div>
<div class="row" style="text-align: center; margin-top: 20px; max-width: 600px; margin-bottom: 20px ! important;">
	<form action="login" method="post" accept-charset="utf-8">
		<table class="table">
			<tr class=" span info">
		    	<td class="col-md-3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;用户名：</td>
				<td class="col-md-4">
		 	 	<input type="text"  name="username" class="form-control"  placeholder="请输入"/>
				</td>
			</tr>
		    <tr class=" span info">
		    	<td class="col-md-3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;密码：</td>
				<td class="col-md-4">
		 	 	<input type="password"  name="password" class="form-control"  placeholder="请输入"/>
				</td>
			</tr>
		</table>
		<input type="submit" class="btn btn-info" value="登录"/>	
	</form>
	
</div>
</center>
