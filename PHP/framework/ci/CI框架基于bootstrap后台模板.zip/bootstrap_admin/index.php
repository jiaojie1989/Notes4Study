<?php
header("Location:manager.php");