<?php
/*网站基本信息配置*/
/*author wangjian*/
/*time 2014_03_03*/
$cdf_install ='install/';
$cfg_cookie_encode ='UsSQu3494J';
$cfg_tu ='125689';
$cfg_isopen_huiyuan ='Y';
$des ='我的站点';
$cfg_zhian_open ='N';
$cfg_pin ='100';
$cfg_memcsche ='N';
$cfg-xingneng ='120';
$yyuuu ='1233';
$cfg_ssa_ ='爱的';
