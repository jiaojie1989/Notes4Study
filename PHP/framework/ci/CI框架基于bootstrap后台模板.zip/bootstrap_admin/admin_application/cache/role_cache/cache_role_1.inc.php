<?php
/*团队角色缓存*/
/*author wangjian*/
/*time 2014_03_01*/
$role_array = array(
'0' => 'main/index/',
'1' => 'sysconfig/index/',
'2' => 'sysconfig/add/',
'3' => 'category/index/',
'4' => 'category/add/',
'5' => 'category_data/index/',
'6' => 'category_data/add/',
);
?>