<?php
/*用户特殊的权限缓存*/
/*author wangjian*/
/*time 2014_03_01*/
$admin_perm_array = array(
);
?>