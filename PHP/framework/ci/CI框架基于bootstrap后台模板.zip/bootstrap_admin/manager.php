<?php

//jump to login page

header("Location:admin.php/login/index");