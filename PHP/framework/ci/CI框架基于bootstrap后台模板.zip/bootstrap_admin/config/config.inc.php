<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
 * 自定义数据库信息 ，注意 $db['default']['autoinit']定义为false
 * */
/*----------------------------此项目所用到的------------------------*/
$db['real_data']['hostname'] = '127.0.0.1';
$db['real_data']['username'] = 'webuser';
$db['real_data']['password'] = 'webadmin';
$db['real_data']['database'] = 'bootstrap_admin';
$db['real_data']['dbdriver'] = 'mysql';
$db['real_data']['dbprefix'] = '';
$db['real_data']['pconnect'] = false;
$db['real_data']['db_debug'] = TRUE;
$db['real_data']['cache_on'] = FALSE;
$db['real_data']['cachedir'] = '';
$db['real_data']['char_set'] = 'utf8';
$db['real_data']['dbcollat'] = 'utf8_general_ci';
$db['real_data']['swap_pre'] = '';
$db['real_data']['autoinit'] = false;
$db['real_data']['stricton'] = FALSE;
$db['real_data']['table_pre'] = '57sy_';  //数据表的前缀
/*----------------------------此项目所用到的------------------------*/

