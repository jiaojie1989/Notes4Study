<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Newcontroller extends CI_Controller{
	function Newcontroller(){
		parent::__construct() ;
	}
}