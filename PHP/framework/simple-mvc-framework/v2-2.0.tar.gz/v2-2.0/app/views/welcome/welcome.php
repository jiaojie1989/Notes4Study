<h1>Welcome</h1>
<hr />
<p>Hello, welcome from the welcome controller!</p>
<p>This content can be changed in /views/welcome/welcome.php</p>

