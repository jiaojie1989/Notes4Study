<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $data['title'].' - '.SITETITLE; //SITETITLE defined in index.php?></title>
	<link href="<?php echo url::get_template_path();?>css/style.css" rel="stylesheet">
</head>
<body>

<div id='wrapper'>
