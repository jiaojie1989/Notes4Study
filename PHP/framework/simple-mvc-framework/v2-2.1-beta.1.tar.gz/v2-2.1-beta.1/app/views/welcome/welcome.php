<h1><?php echo $data['title']; ?></h1>
<hr />
<p>Hello, welcome from the welcome controller!</p>
<p>This content can be changed in /app/views/welcome/welcome.php</p>

