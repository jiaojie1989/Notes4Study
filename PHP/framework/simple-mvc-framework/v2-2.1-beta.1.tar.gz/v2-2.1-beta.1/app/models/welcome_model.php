<?php

class Welcome_model extends Model {

	public function __construct(){
		parent::__construct();
	}

}