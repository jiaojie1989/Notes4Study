Pop PHP Framework Installation
==============================

The Pop PHP Framework requires no special installation steps. Simply
download the framework and extract it. If you change the relationship of
the 'public/bootstrap.php' file to the location of the 'vendor' folder,
you'll have to make that adjustment in the 'require_once' statement
in the 'public/bootstrap.php' file.


SYSTEM REQUIREMENTS
-------------------

Please see README.md.


DEVELOPMENT VERSIONS
--------------------

The Pop PHP Framework is available for checkout via GitHub at  
https://github.com/nicksagona/PopPHP

Further contact or comments can be emailed to info@popphp.org.
