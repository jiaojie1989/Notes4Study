<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!-- Header //-->
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<head>

    <title>
        File Upload Test
    </title>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

</head>

<body>

<form action="upload-process.php" method="post" enctype="multipart/form-data">
    <div>
        <input type="file" name="upload_file" size="50" /><br />
        <input type="submit" name="submit" value="upload" />
    </div>
</form>

</body>

</html>