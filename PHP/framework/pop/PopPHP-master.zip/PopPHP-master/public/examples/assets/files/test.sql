INSERT INTO `users` (`id`, `username`, `password`, `email`, `access`) VALUES
(1, 'test1', 'password1', 'test1@test.com', 'editor'),
(2, 'test2', 'password2', 'test2@test.com', 'editor'),
(3, 'test3', 'password3', 'test3@test.com', 'publisher'),
(4, 'test4', 'password4', 'test4@test.com', 'admin'),
(5, 'test5', 'password5', 'test5@test.com', 'reader'),
(6, 'test6', 'password6', 'test6@test.com', 'editor'),
(7, 'test7', 'pass, word7', 'test7@test.com', 'publisher'),
(8, 'test8', 'password8', 'test8@test.com', 'admin'),
(9, 'newtest1', '123456', 'newtest1@test.com', 're\'ader');
